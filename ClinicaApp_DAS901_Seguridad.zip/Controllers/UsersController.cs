using ClinicaApp.DTOs;
using ClinicaApp.Security;
using ClinicaApp.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ClinicaApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Policy = AuthorizationPolicies.UsuarioActivoRequerido)]
    public class UsersController : ControllerBase
    {
        private readonly IIdentityClinicUserService _userService;

        public UsersController(IIdentityClinicUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        [Authorize(Policy = AuthorizationPolicies.SoloAdministradores)]
        public async Task<IActionResult> GetAll()
        {
            var users = await _userService.GetAllUsersAsync();
            return Ok(users);
        }

        [HttpGet("{id}")]
        [Authorize(Policy = AuthorizationPolicies.PersonalMedico)]
        public async Task<IActionResult> GetById(string id)
        {
            var user = await _userService.GetUserByIdAsync(id);
            if (user == null) return NotFound(new { mensaje = "Usuario no encontrado." });
            return Ok(user);
        }

        [HttpPost]
        [Authorize(Policy = AuthorizationPolicies.SoloAdministradores)]
        public async Task<IActionResult> CreateUser([FromBody] RegisterUserDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var (succeeded, user, errors) = await _userService.RegisterUserAsync(dto);
            if (!succeeded) return BadRequest(new { errores = errors });

            return CreatedAtAction(nameof(GetById), new { id = user!.Id }, user);
        }

        [HttpPut("{id}")]
        [Authorize(Policy = AuthorizationPolicies.SoloAdministradores)]
        public async Task<IActionResult> Update(string id, [FromBody] UpdateUserDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var (succeeded, error) = await _userService.UpdateUserAsync(id, dto);
            if (!succeeded) return BadRequest(new { mensaje = error });

            return NoContent();
        }

        [HttpDelete("{id}")]
        [Authorize(Policy = AuthorizationPolicies.SoloAdministradores)]
        public async Task<IActionResult> Delete(string id)
        {
            var (succeeded, error) = await _userService.DeleteUserAsync(id);
            if (!succeeded) return BadRequest(new { mensaje = error });

            return NoContent();
        }
    }
}
