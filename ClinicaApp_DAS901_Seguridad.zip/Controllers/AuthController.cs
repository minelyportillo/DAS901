using ClinicaApp.DTOs;
using ClinicaApp.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ClinicaApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IIdentityClinicUserService _userService;

        public AuthController(IIdentityClinicUserService userService)
        {
            _userService = userService;
        }

        /// <summary>
        /// Autentica un usuario y devuelve un token JWT.
        /// </summary>
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var (succeeded, response, error) = await _userService.LoginAsync(dto);
            if (!succeeded)
            {
                return Unauthorized(new { mensaje = error });
            }

            return Ok(response);
        }

        /// <summary>
        /// Registro público de nuevos pacientes.
        /// </summary>
        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] RegisterUserDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            dto.RolInicial = "Paciente"; // Por seguridad, auto-registro asigna rol Paciente
            var (succeeded, user, errors) = await _userService.RegisterUserAsync(dto);

            if (!succeeded)
            {
                return BadRequest(new { errores = errors });
            }

            return CreatedAtAction(nameof(Login), new { email = user!.Email }, user);
        }
    }
}
