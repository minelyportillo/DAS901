using ClinicaApp.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ClinicaApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // Requiere estar autenticado con JWT válido
    public class ClinicaOperacionesController : ControllerBase
    {
        [HttpGet("perfil-actual")]
        public IActionResult GetPerfilActual()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var nombre = User.FindFirstValue(ClaimTypes.Name);
            var email = User.FindFirstValue(ClaimTypes.Email);
            var roles = User.FindAll(ClaimTypes.Role).Select(c => c.Value);

            return Ok(new { userId, nombre, email, roles });
        }

        [HttpGet("expedientes-medicos")]
        [Authorize(Policy = AuthorizationPolicies.PersonalMedico)]
        public IActionResult GetExpedientesMedicos()
        {
            return Ok(new { mensaje = "Acceso concedido: Expedientes clínicos disponibles para Médicos y Administradores." });
        }

        [HttpPost("agendar-cita")]
        [Authorize(Policy = AuthorizationPolicies.GestionCitas)]
        public IActionResult AgendarCita()
        {
            return Ok(new { mensaje = "Acceso concedido mediante política GestionCitas (Admin, Recepcionista o Claim GestionTotal)." });
        }
    }
}
