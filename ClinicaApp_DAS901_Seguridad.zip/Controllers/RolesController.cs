using ClinicaApp.DTOs;
using ClinicaApp.Models;
using ClinicaApp.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClinicaApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Policy = AuthorizationPolicies.SoloAdministradores)]
    public class RolesController : ControllerBase
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;

        public RolesController(RoleManager<IdentityRole> roleManager, UserManager<ApplicationUser> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<IActionResult> GetRoles()
        {
            var roles = await _roleManager.Roles.Select(r => new { r.Id, r.Name }).ToListAsync();
            return Ok(roles);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRole([FromBody] RoleDto dto)
        {
            if (await _roleManager.RoleExistsAsync(dto.NombreRol))
                return BadRequest(new { mensaje = "El rol ya existe." });

            var result = await _roleManager.CreateAsync(new IdentityRole(dto.NombreRol));
            if (!result.Succeeded)
                return BadRequest(result.Errors);

            return Ok(new { mensaje = $"Rol '{dto.NombreRol}' creado correctamente." });
        }

        [HttpPost("assign")]
        public async Task<IActionResult> AssignRoleToUser([FromBody] AssignRoleDto dto)
        {
            var user = await _userManager.FindByIdAsync(dto.UserId);
            if (user == null) return NotFound(new { mensaje = "Usuario no encontrado." });

            if (!await _roleManager.RoleExistsAsync(dto.RoleName))
                return NotFound(new { mensaje = "Rol no encontrado." });

            var result = await _userManager.AddToRoleAsync(user, dto.RoleName);
            if (!result.Succeeded) return BadRequest(result.Errors);

            return Ok(new { mensaje = $"Rol '{dto.RoleName}' asignado a '{user.Email}'." });
        }

        [HttpPost("remove")]
        public async Task<IActionResult> RemoveRoleFromUser([FromBody] AssignRoleDto dto)
        {
            var user = await _userManager.FindByIdAsync(dto.UserId);
            if (user == null) return NotFound(new { mensaje = "Usuario no encontrado." });

            var result = await _userManager.RemoveFromRoleAsync(user, dto.RoleName);
            if (!result.Succeeded) return BadRequest(result.Errors);

            return Ok(new { mensaje = $"Rol '{dto.RoleName}' removido de '{user.Email}'." });
        }
    }
}
