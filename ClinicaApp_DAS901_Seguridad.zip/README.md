# Módulo de Seguridad - ClinicaApp (DAS901)

Este paquete contiene la implementación completa de los puntos **2.1 a 2.7** en **ASP.NET Core (.NET 8)**:

## Estructura incluida

- **2.1 ASP.NET Identity**:
  - `Models/ApplicationUser.cs`: Extiende `IdentityUser` con `NombreCompleto`, `Especialidad`, `FechaRegistro` y `Activo`.
  - `Data/ClinicaDbContext.cs`: Hereda de `IdentityDbContext<ApplicationUser, IdentityRole, string>` y personaliza las tablas (`Usuarios`, `Roles`, etc.).
  - `Program.cs`: Configuración de reglas de contraseñas, bloqueo por intentos fallidos (`Lockout`) y almacén EF Core.
- **2.2 Gestión de usuarios**:
  - `Services/IdentityClinicUserService.cs` & `Controllers/UsersController.cs`: CRUD completo de usuarios (listar, consultar por ID, crear con rol inicial, actualizar estado/datos y eliminar).
- **2.3 Gestión de roles**:
  - `Controllers/RolesController.cs` & `Data/DbInitializer.cs`: Creación de roles (`Admin`, `Medico`, `Recepcionista`, `Paciente`), listado, asignación y remoción de roles a usuarios.
- **2.4 Políticas de autorización**:
  - `Security/AuthorizationPolicies.cs`: Políticas personalizadas (`SoloAdministradores`, `PersonalMedico`, `GestionCitas` combinando roles y claims, y `UsuarioActivoRequerido`).
- **2.5 JWT (JSON Web Token)**:
  - `Services/JwtTokenService.cs` & `appsettings.json`: Generación de tokens firmados con HMAC-SHA256 incrustando `Id`, `Email`, `Roles` y `Claims`.
- **2.6 Autenticación**:
  - `Controllers/AuthController.cs` & `Program.cs`: Esquema `JwtBearerDefaults.AuthenticationScheme`, endpoints `/api/Auth/login` y `/api/Auth/register`, más middleware `app.UseAuthentication()`.
- **2.7 Autorización**:
  - Implementada mediante atributos `[Authorize]`, `[AllowAnonymous]` y `[Authorize(Policy = ...)]` en `UsersController`, `RolesController` y `ClinicaOperacionesController`, junto con Swagger configurado para pruebas con Bearer Token.

## Credenciales iniciales (Seed)
- **Email:** `admin@clinicaapp.com`
- **Password:** `Admin123!`
