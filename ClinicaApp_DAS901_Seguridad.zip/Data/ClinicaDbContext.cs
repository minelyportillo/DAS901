using ClinicaApp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ClinicaApp.Data
{
    public class ClinicaDbContext : IdentityDbContext<ApplicationUser, IdentityRole, string>
    {
        public ClinicaDbContext(DbContextOptions<ClinicaDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Personalización de tablas de Identity
            builder.Entity<ApplicationUser>(entity => entity.ToTable("Usuarios"));
            builder.Entity<IdentityRole>(entity => entity.ToTable("Roles"));
            builder.Entity<IdentityUserRole<string>>(entity => entity.ToTable("UsuarioRoles"));
            builder.Entity<IdentityUserClaim<string>>(entity => entity.ToTable("UsuarioClaims"));
            builder.Entity<IdentityUserLogin<string>>(entity => entity.ToTable("UsuarioLogins"));
            builder.Entity<IdentityRoleClaim<string>>(entity => entity.ToTable("RolClaims"));
            builder.Entity<IdentityUserToken<string>>(entity => entity.ToTable("UsuarioTokens"));
        }
    }
}
