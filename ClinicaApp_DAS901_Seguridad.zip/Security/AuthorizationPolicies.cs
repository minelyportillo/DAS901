using Microsoft.AspNetCore.Authorization;

namespace ClinicaApp.Security
{
    public static class AuthorizationPolicies
    {
        public const string SoloAdministradores = "SoloAdministradores";
        public const string PersonalMedico = "PersonalMedico";
        public const string GestionCitas = "GestionCitas";
        public const string UsuarioActivoRequerido = "UsuarioActivoRequerido";

        public static void ConfigurePolicies(AuthorizationOptions options)
        {
            // Política basada en Rol único
            options.AddPolicy(SoloAdministradores, policy =>
                policy.RequireRole("Admin"));

            // Política basada en múltiples Roles
            options.AddPolicy(PersonalMedico, policy =>
                policy.RequireRole("Admin", "Medico"));

            // Política combinada de Roles y Claims
            options.AddPolicy(GestionCitas, policy =>
                policy.RequireAssertion(context =>
                    context.User.IsInRole("Admin") ||
                    context.User.IsInRole("Recepcionista") ||
                    context.User.HasClaim(c => c.Type == "PermisoEspecial" && c.Value == "GestionTotal")));

            // Política basada en Claim de estado activo
            options.AddPolicy(UsuarioActivoRequerido, policy =>
                policy.RequireClaim("Activo", "True"));
        }
    }
}
