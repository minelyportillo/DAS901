using System.ComponentModel.DataAnnotations;

namespace ClinicaApp.DTOs
{
    // 2.6 Autenticación
    public class LoginDto
    {
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;
    }

    public class AuthResponseDto
    {
        public string Token { get; set; } = string.Empty;
        public DateTime Expiracion { get; set; }
        public string Email { get; set; } = string.Empty;
        public string NombreCompleto { get; set; } = string.Empty;
        public IList<string> Roles { get; set; } = new List<string>();
    }

    // 2.2 Gestión de usuarios
    public class RegisterUserDto
    {
        [Required]
        public string NombreCompleto { get; set; } = string.Empty;

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required, MinLength(6)]
        public string Password { get; set; } = string.Empty;

        public string Especialidad { get; set; } = string.Empty;
        public string RolInicial { get; set; } = "Paciente";
    }

    public class UpdateUserDto
    {
        [Required]
        public string NombreCompleto { get; set; } = string.Empty;
        public string Especialidad { get; set; } = string.Empty;
        public bool Activo { get; set; }
    }

    public class UserResponseDto
    {
        public string Id { get; set; } = string.Empty;
        public string NombreCompleto { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Especialidad { get; set; } = string.Empty;
        public bool Activo { get; set; }
        public IList<string> Roles { get; set; } = new List<string>();
    }

    // 2.3 Gestión de roles
    public class RoleDto
    {
        [Required]
        public string NombreRol { get; set; } = string.Empty;
    }

    public class AssignRoleDto
    {
        [Required]
        public string UserId { get; set; } = string.Empty;

        [Required]
        public string RoleName { get; set; } = string.Empty;
    }
}
