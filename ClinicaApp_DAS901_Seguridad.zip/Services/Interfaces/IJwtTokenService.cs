using ClinicaApp.Models;

namespace ClinicaApp.Services.Interfaces
{
    public interface IJwtTokenService
    {
        Task<(string Token, DateTime Expiration)> GenerateTokenAsync(ApplicationUser user);
    }
}
