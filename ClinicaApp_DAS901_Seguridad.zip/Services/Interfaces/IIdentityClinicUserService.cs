using ClinicaApp.DTOs;

namespace ClinicaApp.Services.Interfaces
{
    public interface IIdentityClinicUserService
    {
        Task<(bool Succeeded, AuthResponseDto? Response, string Error)> LoginAsync(LoginDto dto);
        Task<(bool Succeeded, UserResponseDto? User, IEnumerable<string> Errors)> RegisterUserAsync(RegisterUserDto dto);
        Task<IEnumerable<UserResponseDto>> GetAllUsersAsync();
        Task<UserResponseDto?> GetUserByIdAsync(string id);
        Task<(bool Succeeded, string Error)> UpdateUserAsync(string id, UpdateUserDto dto);
        Task<(bool Succeeded, string Error)> DeleteUserAsync(string id);
    }
}
