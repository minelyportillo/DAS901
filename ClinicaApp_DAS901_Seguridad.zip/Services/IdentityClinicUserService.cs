using ClinicaApp.DTOs;
using ClinicaApp.Models;
using ClinicaApp.Services.Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ClinicaApp.Services
{
    public class IdentityClinicUserService : IIdentityClinicUserService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IJwtTokenService _jwtTokenService;

        public IdentityClinicUserService(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            RoleManager<IdentityRole> roleManager,
            IJwtTokenService jwtTokenService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _jwtTokenService = jwtTokenService;
        }

        public async Task<(bool Succeeded, AuthResponseDto? Response, string Error)> LoginAsync(LoginDto dto)
        {
            var user = await _userManager.FindByEmailAsync(dto.Email);
            if (user == null || !user.Activo)
            {
                return (false, null, "Credenciales inválidas o usuario inactivo.");
            }

            var result = await _signInManager.CheckPasswordSignInAsync(user, dto.Password, lockoutOnFailure: true);
            if (!result.Succeeded)
            {
                if (result.IsLockedOut)
                    return (false, null, "Cuenta bloqueada temporalmente por múltiples intentos fallidos.");
                return (false, null, "Credenciales inválidas.");
            }

            var (token, expiration) = await _jwtTokenService.GenerateTokenAsync(user);
            var roles = await _userManager.GetRolesAsync(user);

            return (true, new AuthResponseDto
            {
                Token = token,
                Expiracion = expiration,
                Email = user.Email!,
                NombreCompleto = user.NombreCompleto,
                Roles = roles
            }, string.Empty);
        }

        public async Task<(bool Succeeded, UserResponseDto? User, IEnumerable<string> Errors)> RegisterUserAsync(RegisterUserDto dto)
        {
            var user = new ApplicationUser
            {
                UserName = dto.Email,
                Email = dto.Email,
                NombreCompleto = dto.NombreCompleto,
                Especialidad = dto.Especialidad,
                Activo = true
            };

            var result = await _userManager.CreateAsync(user, dto.Password);
            if (!result.Succeeded)
            {
                return (false, null, result.Errors.Select(e => e.Description));
            }

            var roleToAssign = string.IsNullOrWhiteSpace(dto.RolInicial) ? "Paciente" : dto.RolInicial;
            if (await _roleManager.RoleExistsAsync(roleToAssign))
            {
                await _userManager.AddToRoleAsync(user, roleToAssign);
            }

            var roles = await _userManager.GetRolesAsync(user);
            return (true, new UserResponseDto
            {
                Id = user.Id,
                NombreCompleto = user.NombreCompleto,
                Email = user.Email!,
                Especialidad = user.Especialidad,
                Activo = user.Activo,
                Roles = roles
            }, Array.Empty<string>());
        }

        public async Task<IEnumerable<UserResponseDto>> GetAllUsersAsync()
        {
            var users = await _userManager.Users.ToListAsync();
            var list = new List<UserResponseDto>();

            foreach (var u in users)
            {
                list.Add(new UserResponseDto
                {
                    Id = u.Id,
                    NombreCompleto = u.NombreCompleto,
                    Email = u.Email ?? string.Empty,
                    Especialidad = u.Especialidad,
                    Activo = u.Activo,
                    Roles = await _userManager.GetRolesAsync(u)
                });
            }
            return list;
        }

        public async Task<UserResponseDto?> GetUserByIdAsync(string id)
        {
            var u = await _userManager.FindByIdAsync(id);
            if (u == null) return null;

            return new UserResponseDto
            {
                Id = u.Id,
                NombreCompleto = u.NombreCompleto,
                Email = u.Email ?? string.Empty,
                Especialidad = u.Especialidad,
                Activo = u.Activo,
                Roles = await _userManager.GetRolesAsync(u)
            };
        }

        public async Task<(bool Succeeded, string Error)> UpdateUserAsync(string id, UpdateUserDto dto)
        {
            var u = await _userManager.FindByIdAsync(id);
            if (u == null) return (false, "Usuario no encontrado.");

            u.NombreCompleto = dto.NombreCompleto;
            u.Especialidad = dto.Especialidad;
            u.Activo = dto.Activo;

            var result = await _userManager.UpdateAsync(u);
            return result.Succeeded
                ? (true, string.Empty)
                : (false, string.Join(", ", result.Errors.Select(e => e.Description)));
        }

        public async Task<(bool Succeeded, string Error)> DeleteUserAsync(string id)
        {
            var u = await _userManager.FindByIdAsync(id);
            if (u == null) return (false, "Usuario no encontrado.");

            var result = await _userManager.DeleteAsync(u);
            return result.Succeeded
                ? (true, string.Empty)
                : (false, string.Join(", ", result.Errors.Select(e => e.Description)));
        }
    }
}
