using ClinicaApp.Data;
using ClinicaApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ClinicaApp.Repositories
{
    public class PacienteRepository : IPacienteRepository
    {
        private readonly ClinicaDbContext _context;

        public PacienteRepository(ClinicaDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Paciente>> GetAllAsync()
        {
            return await _context.Pacientes.ToListAsync();
        }

        public async Task<Paciente?> GetByIdAsync(int id)
        {
            return await _context.Pacientes.FindAsync(id);
        }

        public async Task<Paciente?> GetByDuiAsync(string dui)
        {
            return await _context.Pacientes.FirstOrDefaultAsync(p => p.Dui == dui);
        }

        public async Task<IEnumerable<Paciente>> SearchAsync(string query)
        {
            return await _context.Pacientes
                .Where(p => p.NombreCompleto.Contains(query) || p.Dui.Contains(query))
                .ToListAsync();
        }

        public async Task AddAsync(Paciente entity)
        {
            await _context.Pacientes.AddAsync(entity);
        }

        public void Update(Paciente entity)
        {
            _context.Pacientes.Update(entity);
        }

        public void Delete(Paciente entity)
        {
            _context.Pacientes.Remove(entity);
        }

        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
