using ClinicaApp.Models;
using ClinicaApp.Repositories;
using ClinicaApp.ViewModels;

namespace ClinicaApp.Services
{
    public class PacienteService : IPacienteService
    {
        private readonly IPacienteRepository _pacienteRepository;

        public PacienteService(IPacienteRepository pacienteRepository)
        {
            _pacienteRepository = pacienteRepository;
        }

        public async Task<IEnumerable<Paciente>> ObtenerTodosAsync()
        {
            return await _pacienteRepository.GetAllAsync();
        }

        public async Task<Paciente?> ObtenerPorIdAsync(int id)
        {
            return await _pacienteRepository.GetByIdAsync(id);
        }

        public async Task<Paciente?> ObtenerPorDuiAsync(string dui)
        {
            return await _pacienteRepository.GetByDuiAsync(dui);
        }

        public async Task<bool> RegistrarPacienteAsync(RegistrarPacienteViewModel model)
        {
            var existente = await _pacienteRepository.GetByDuiAsync(model.Dui);
            if (existente != null)
            {
                return false; // Paciente ya existe
            }

            var paciente = new Paciente
            {
                NombreCompleto = model.NombreCompleto,
                Dui = model.Dui,
                FechaNacimiento = model.FechaNacimiento,
                Telefono = model.Telefono,
                Direccion = model.Direccion,
                Genero = model.Genero
            };

            await _pacienteRepository.AddAsync(paciente);
            await _pacienteRepository.SaveAsync();
            return true;
        }
    }
}
