using ClinicaApp.Models;
using ClinicaApp.ViewModels;

namespace ClinicaApp.Services
{
    public interface IPacienteService
    {
        Task<IEnumerable<Paciente>> ObtenerTodosAsync();
        Task<Paciente?> ObtenerPorIdAsync(int id);
        Task<Paciente?> ObtenerPorDuiAsync(string dui);
        Task<bool> RegistrarPacienteAsync(RegistrarPacienteViewModel model);
    }
}
